package co.edu.uptc.client.interfaces;

import java.io.IOException;

public interface NetClientInterface {

    void connect(String host, int port) throws IOException;

    void sendMessage(Object dto);

    void disconnect();
}

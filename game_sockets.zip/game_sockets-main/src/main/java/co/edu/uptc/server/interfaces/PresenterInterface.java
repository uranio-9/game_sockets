package co.edu.uptc.server.interfaces;
public interface PresenterInterface extends ModelObserver {
    void setModel(ModelInterface model);
    void setView(ViewInterface view);

    void onConnectReceived(String studentCode);
    void onMoveReceived(String studentCode, String direction);
    void onDisconnectReceived(String studentCode);

    void onStartGameClicked();
    void onFinishGameClicked();
    void startNetwork(int port);

    void setBroadcaster(ServerBroadcasterInterface broadcaster);

    boolean isGameStarted();
}

package co.edu.uptc.shared.util;

import com.google.gson.*;

public class JsonUtils {
    private static final Gson GSON = new Gson();

    public static String toJson(Object object) {
        return GSON.toJson(object);
    }

    public static <T> T fromJson(String json, Class<T> clazz) {
        return GSON.fromJson(json, clazz);
    }

    public static String getType(String json) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            JsonElement el = obj.get("type");
            return (el != null && !el.isJsonNull()) ? el.getAsString() : null;
        } catch (Exception e) {
            return null;
        }
    }
}

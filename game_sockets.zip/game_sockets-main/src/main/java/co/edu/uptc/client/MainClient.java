package co.edu.uptc.client;

import co.edu.uptc.client.presenter.ClientRunner;

public class MainClient {
    public static void main(String[] args) {
        new ClientRunner().start();
    }
}

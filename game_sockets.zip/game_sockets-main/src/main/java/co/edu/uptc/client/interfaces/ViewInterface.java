package co.edu.uptc.client.interfaces;

import co.edu.uptc.shared.dto.GameState;

public interface ViewInterface {

    void setPresenter(PresenterInterface presenter);
    void start();

    void updateBoard(GameState state);

    void updatePersonalInfo(String role, int totalScore);

    void showGameEnd(String reason);

    void showErrorAndExit(String message);
}
